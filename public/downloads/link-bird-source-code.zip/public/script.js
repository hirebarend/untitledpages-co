// https://l.linkbird.io/public/script.min.js

function generateId(length) {
  const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';

  let result = '';

  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }

  return result;
}

function LinkBirdPixel() {
  let id = localStorage.getItem('link-bird-pixel-id');

  if (!id) {
    id = generateId(12);

    localStorage.setItem('link-bird-pixel-id', id);
  }

  const payload = {
    consumerId: 'xuJMNGBDZTdKy0iJUeuYnTRz2gP2',
    metadata: {
      id,
    },
    tags: [],
    type: 'PageView',
  };

  fetch('https://l.linkbird.io/api/v1/pixel/events', {
    method: 'POST',
    headers: {
      'Content-type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
}

if (document.readyState !== 'loading') {
  LinkBirdPixel();
} else {
  document.addEventListener('DOMContentLoaded', function () {
    LinkBirdPixel();
  });
}

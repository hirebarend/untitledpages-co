export type Consumer = {
  id: string;

  subscription: {
    frequency: 'daily' | 'monthly';

    limit: number;

    name: string;
  };
};

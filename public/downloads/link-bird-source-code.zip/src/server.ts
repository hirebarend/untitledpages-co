import fastify from 'fastify';
import fastifyCors from '@fastify/cors';
import fastifyStatic from '@fastify/static';
import fastifySwagger from '@fastify/swagger';
import fastifySwaggerUi from '@fastify/swagger-ui';
import fastifyView from '@fastify/view';
import path from 'path';
import {
  CLICKS_GET,
  CODE_GET,
  CODE_GET_LEGACY,
  LINKS_CODE_DELETE,
  LINKS_CODE_GET,
  LINKS_GET,
  LINKS_POST,
  LINKS_PUT,
  PIXEL_EVENTS_GET,
  PIXEL_EVENTS_POST,
} from './routes';
import { BEETLE_LOGS_GET, BEETLE_TOKENS_GET, BEETLE_TOKENS_POST } from './core';

export async function startServer() {
  const server = fastify({
    logger: true,
  });

  await server.register(fastifyCors, {
    allowedHeaders: '*',
    origin: '*',
  });

  server.register(fastifyStatic, {
    root: path.join(__dirname, '..', 'public'),
    prefix: '/public/',
  });

  server.register(fastifyView, {
    engine: {
      handlebars: require('handlebars'),
    },
  });

  await server.register(fastifySwagger, {
    swagger: {
      consumes: ['application/json'],
      host: process.env.HOST || 'localhost:8080',
      info: {
        description:
          'An API-first alternative to Bitly, Dub.co, Bl.ink, Short.io and many others.',
        title: 'Link Bird API Specification',
        version: '0.1.0',
      },
      produces: ['application/json'],
      schemes: process.env.DEBUG ? ['http'] : ['https', 'http'],
      securityDefinitions: process.env.DEBUG
        ? undefined
        : {
            apiKey: {
              type: 'apiKey',
              name: 'Authorization',
              in: 'header',
            },
          },
    },
  });

  await server.register(fastifySwaggerUi, {
    routePrefix: '/docs',
  });

  server.route(BEETLE_LOGS_GET);

  server.route(BEETLE_TOKENS_GET);

  server.route(BEETLE_TOKENS_POST);

  server.route(CLICKS_GET);

  server.route(LINKS_GET);

  server.route(LINKS_POST);

  server.route(LINKS_PUT);

  server.route(LINKS_CODE_DELETE);

  server.route(LINKS_CODE_GET);

  server.route(PIXEL_EVENTS_GET);

  server.route(PIXEL_EVENTS_POST);

  server.route(CODE_GET_LEGACY);

  server.route(CODE_GET);

  server.route({
    handler: async (request, reply) => {
      reply.redirect(302, 'https://linkbird.io');
    },
    method: 'GET',
    url: '/',
    schema: {
      tags: ['X-HIDDEN'],
    },
  });

  server.route({
    handler: async (request, reply) => {
      let healthy: boolean = true;

      if (!healthy) {
        reply.status(503).send();

        return;
      }

      reply.status(200).send();
    },
    method: 'GET',
    url: '/api/v1/health',
  });

  server.route({
    handler: async (request, reply) => {
      reply.status(200).send();
    },
    method: 'GET',
    url: '/api/v1/ping',
  });

  await server.listen({
    host: '0.0.0.0',
    port: process.env.PORT ? parseInt(process.env.PORT) : 8080,
  });

  await server.ready();
}

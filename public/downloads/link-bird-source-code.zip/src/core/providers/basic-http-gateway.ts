import axios from 'axios';
import dns from 'dns';
import http from 'http';
import https from 'https';
import ip from 'ip';

export class BasicHttpGateway {
  protected static httpAgent = new http.Agent({
    keepAlive: true,
    maxFreeSockets: 256,
    maxSockets: 100,
    maxTotalSockets: 1000,
    timeout: 3000,
  });

  protected static httpsAgent = new https.Agent({
    keepAlive: true,
    maxFreeSockets: 256,
    maxSockets: 100,
    maxTotalSockets: 1000,
    timeout: 3000,
  });

  public static async post(url: string, payload: any): Promise<number> {
    if (await BasicHttpGateway.resolvesToPrivateIpAddress(url)) {
      return 0;
    }

    const response = await axios.post(url, JSON.stringify(payload), {
      headers: {
        'User-Agent': 'linkbird.io/0.1.0',
        'Content-Type': 'application/json',
      },
      httpAgent: this.httpAgent,
      httpsAgent: this.httpsAgent,
      maxRedirects: 0,
      responseType: 'stream',
      timeout: 3000,
      validateStatus: (_: number) => {
        return true;
      },
    });

    return response.status;
  }

  protected static async resolvesToPrivateIpAddress(
    url: string,
  ): Promise<boolean> {
    return new Promise((resolve, reject) => {
      dns.lookup(
        new URL(url).hostname,
        (error: Error | null, ipAddress: string) => {
          if (error) {
            reject(error);

            return;
          }

          if (ip.isPrivate(ipAddress)) {
            resolve(true);

            return;
          }

          resolve(false);
        },
      );
    });
  }
}

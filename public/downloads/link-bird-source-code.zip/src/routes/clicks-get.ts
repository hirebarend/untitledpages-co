import { RouteOptions } from 'fastify';
import moment from 'moment';
import { Collection } from 'mongodb';
import { PixelEvent, getContainer } from '../core';

export const CLICKS_GET: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<PixelEvent> =
      container.db.collection<PixelEvent>('pixel-events');

    const consumerId: string | null = process.env.DEBUG
      ? 'DEBUG_CONSUMER'
      : await container.tokenRepository.fromHeader(
          request.headers['authorization'],
        );

    if (!consumerId) {
      reply.status(401).send();

      return;
    }

    const query: {
      period: 'P24H' | 'P7D' | 'P14D' | 'P28D' | null;
    } = request.query as any;

    let timestamp = moment().subtract(24, 'hours').toDate().getTime();

    if (query.period === 'P7D') {
      timestamp = moment().subtract(7, 'days').toDate().getTime();
    } else if (query.period === 'P14D') {
      timestamp = moment().subtract(14, 'days').toDate().getTime();
    } else if (query.period === 'P28D') {
      timestamp = moment().subtract(28, 'days').toDate().getTime();
    }

    const pixelEvents: Array<PixelEvent> = await collection
      .find(
        {
          consumerId,
          timestamp: {
            $gte: timestamp,
          },
          type: 'Click',
        },
        {
          projection: {
            _id: 0,
          },
          sort: {
            timestamp: -1,
          },
        },
      )
      .toArray();

    reply.status(200).send(pixelEvents);
  },
  method: 'GET',
  url: '/api/v1/clicks',
  schema: {
    tags: ['clicks'],
    security: process.env.DEBUG
      ? undefined
      : [
          {
            apiKey: [],
          },
        ],
  },
};

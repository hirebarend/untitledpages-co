import * as applicationinsights from 'applicationinsights';
import cluster from 'cluster';
import os from 'os';
require('dotenv').config();
import { startServer } from './server';
import { BasicHttpGateway, Link, PixelEvent, getContainer } from './core';

applicationinsights
  .setup(process.env.CUSTOM_APPLICATIONINSIGHTS_CONNECTION_STRING)
  .setAutoDependencyCorrelation(true)
  .setAutoCollectRequests(true)
  .setAutoCollectPerformance(false, false) // true, true
  .setAutoCollectExceptions(true)
  .setAutoCollectDependencies(false) // true
  .setAutoCollectConsole(true)
  .setUseDiskRetryCaching(false) // true
  .setSendLiveMetrics(false)
  .setDistributedTracingMode(applicationinsights.DistributedTracingModes.AI)
  .setAutoCollectHeartbeat(false);

applicationinsights.start();

if (process.env.CLUSTER) {
  if (cluster.isPrimary) {
    for (let i = 0; i < os.cpus().length; i++) {
      cluster.fork();
    }

    (async () => {
      const container = await getContainer();

      container.serviceBusReceiver.subscribe(
        {
          processError: async (e) => {},
          processMessage: async (message) => {
            const body: { link: Link; pixelEvent: PixelEvent } = {
              link: message.body.link,
              pixelEvent: message.body.pixelEvent,
            };

            if (!body.link.webhook) {
              return;
            }

            await BasicHttpGateway.post(body.link.webhook, body);
          },
        },
        {
          maxConcurrentCalls: 50,
        },
      );
    })();
  } else {
    startServer();
  }
} else {
  (async () => {
    const container = await getContainer();

    container.serviceBusReceiver.subscribe(
      {
        processError: async (e) => {},
        processMessage: async (message) => {
          const body: { link: Link; pixelEvent: PixelEvent } = {
            link: message.body.link,
            pixelEvent: message.body.pixelEvent,
          };

          if (!body.link.webhook) {
            return;
          }

          await BasicHttpGateway.post(body.link.webhook, body);
        },
      },
      {
        maxConcurrentCalls: 50,
      },
    );
  })();

  startServer();
}

import { RouteOptions } from 'fastify';
import ip3country from 'ip3country';
import { isbot } from 'isbot';
import { Collection } from 'mongodb';
import path from 'path';
import { UAParser } from 'ua-parser-js';
import { Link, PixelEvent, getContainer } from '../core';

ip3country.init();

async function pushPixelEvent(
  collection: Collection<PixelEvent>,
  link: Link,
  ipAddress: string | null,
  userAgent: string | null,
  referrer: string | null,
  type: 'Bot' | 'Click' | 'Redirect',
) {
  const country: string | null = ipAddress
    ? ip3country.lookupStr(ipAddress)
    : null;

  const geoTargeting = link.geoTargeting.find((x) => x.country === country);

  const pixelEvent: PixelEvent = {
    consumerId: link.consumerId,
    country,
    ipAddress: ipAddress || '',
    metadata: {
      code: link.code,
      longUrl: geoTargeting ? geoTargeting.longUrl : link.longUrl,
    },
    referrer,
    tags: link.tags,
    timestamp: new Date().getTime(),
    type,
    userAgent: new UAParser(userAgent || '').getResult(),
  };

  await collection.insertOne({
    ...pixelEvent,
  });

  return pixelEvent;
}

const handler = async (request: any, reply: any) => {
  const container = await getContainer();

  const params: { code: string } = request.params as any;

  const collection: Collection<Link> = container.db.collection<Link>('links');

  const collectionPixelEvents: Collection<PixelEvent> =
    container.db.collection<PixelEvent>('pixel-events');

  const link: Link | null = await collection.findOne(
    {
      code: params.code,
    },
    {
      projection: {
        _id: 0,
      },
    },
  );

  if (!link) {
    reply.status(200).redirect(302, 'https://linkbird.io/link/expired');

    return;
  }

  const ipAddress: string | null = request.headers['x-client-ip'] || null;

  const country: string | null = ipAddress
    ? ip3country.lookupStr(ipAddress)
    : null;

  const userAgent: string | null = request.headers['user-agent'] || null;

  const geoTargeting = link.geoTargeting.find((x) => x.country === country);

  if (isbot(userAgent)) {
    await pushPixelEvent(
      collectionPixelEvents,
      link,
      ipAddress,
      userAgent,
      request.headers['referer'] || null,
      'Bot',
    );

    return reply.view(path.join('public', 'index-static-bot.html'), link);
  }

  if (link.expires && link.expires < new Date().getTime()) {
    await pushPixelEvent(
      collectionPixelEvents,
      link,
      ipAddress,
      userAgent,
      request.headers['referer'] || null,
      'Redirect',
    );

    reply
      .status(200)
      .redirect(302, `https://linkbird.io/link/expired?code=${link.code}`);

    return;
  }

  const pixelEvent: PixelEvent = await pushPixelEvent(
    collectionPixelEvents,
    link,
    ipAddress,
    userAgent,
    request.headers['referer'] || null,
    'Click',
  );

  await collection.updateOne(
    {
      code: link.code,
    },
    {
      $set: {
        clicks: {
          count: link.clicks ? link.clicks.count + 1 : 1,
          timestamp: new Date().getTime(),
        },
      },
    },
  );

  await container.serviceBusSender.sendMessages([
    {
      body: {
        link,
        pixelEvent,
      },
    },
  ]);

  const longUrl: string = geoTargeting ? geoTargeting.longUrl : link.longUrl;

  if (link.cloak) {
    // TODO: implement pixels
    return reply.view(path.join('public', 'index-iframe.html'), {
      ...link,
      longUrl,
    });
  }

  if (link.script) {
    return reply.view(path.join('public', 'index-static.html'), {
      ...link,
      longUrl,
    });
  }

  reply.status(200).redirect(302, longUrl);
};

export const CODE_GET_LEGACY: RouteOptions = {
  handler,
  method: 'GET',
  url: '/_/:code',
  schema: {
    tags: ['X-HIDDEN'],
  },
};

export const CODE_GET: RouteOptions = {
  handler,
  method: 'GET',
  url: '/:code',
  schema: {
    tags: ['X-HIDDEN'],
  },
};

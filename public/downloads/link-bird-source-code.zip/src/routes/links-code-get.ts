import { RouteOptions } from 'fastify';
import { Collection } from 'mongodb';
import { Link, getContainer } from '../core';

export const LINKS_CODE_GET: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<Link> = container.db.collection<Link>('links');

    const consumerId: string | null = process.env.DEBUG
      ? 'DEBUG_CONSUMER'
      : await container.tokenRepository.fromHeader(
          request.headers['authorization'],
        );

    if (!consumerId) {
      reply.status(401).send();

      return;
    }

    const params: { code: string } = request.params as any;

    const link: Link | null = await collection.findOne(
      {
        code: params.code,
        consumerId,
      },
      {
        projection: {
          _id: 0,
        },
      },
    );

    if (!link) {
      reply.status(404).send();

      return;
    }

    reply.status(200).send(link);
  },
  method: 'GET',
  url: '/api/v1/links/:code',
  schema: {
    tags: ['links'],
    security: process.env.DEBUG
      ? undefined
      : [
          {
            apiKey: [],
          },
        ],
  },
};

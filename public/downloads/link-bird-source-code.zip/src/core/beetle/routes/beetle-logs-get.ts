import { FastifyReply, RouteOptions } from 'fastify';
import { Transaction, getContainer } from '../..';

async function handle(request: any, reply: FastifyReply): Promise<void> {
  const container = await getContainer();

  const consumerId: string | null = await container.tokenRepository.fromHeader(
    request.headers['authorization'],
  );

  if (!consumerId) {
    reply.status(401).send();

    return;
  }

  const transactions: Array<Transaction> =
    await container.beetleClient.logs(consumerId);

  reply.status(200).send(transactions);
}

export const BEETLE_LOGS_GET: RouteOptions = {
  handler: handle,
  method: 'GET',
  url: '/api/v1/beetle/logs',
  schema: {
    tags: ['X-HIDDEN'],
    security: [
      {
        apiKey: [],
      },
    ],
  },
};

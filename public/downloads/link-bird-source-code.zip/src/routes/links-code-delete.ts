import { RouteOptions } from 'fastify';
import { Collection } from 'mongodb';
import { Link, getContainer } from '../core';

export const LINKS_CODE_DELETE: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<Link> = container.db.collection<Link>('links');

    const consumerId: string | null = process.env.DEBUG
      ? 'DEBUG_CONSUMER'
      : await container.tokenRepository.fromHeader(
          request.headers['authorization'],
        );

    if (!consumerId) {
      reply.status(401).send();

      return;
    }

    const params: { code: string } = request.params as any;

    await collection.deleteOne({
      code: params.code,
      consumerId,
    });

    reply.status(200).send();
  },
  method: 'DELETE',
  url: '/api/v1/links/:code',
  schema: {
    tags: ['links'],
    security: process.env.DEBUG
      ? undefined
      : [
          {
            apiKey: [],
          },
        ],
  },
};

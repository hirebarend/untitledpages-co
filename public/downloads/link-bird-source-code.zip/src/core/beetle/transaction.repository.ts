import * as mongoDb from 'mongodb';
import * as uuid from 'uuid';
import { Transaction } from './models';

export class TransactionRepository {
  protected readonly collection: mongoDb.Collection<Transaction>;

  constructor(protected db: mongoDb.Db) {
    this.collection = this.db.collection<Transaction>('transactions');
  }

  public async create(consumerId: string, value: number): Promise<Transaction> {
    const transaction: Transaction = {
      consumerId,
      id: uuid.v4(),
      metadata: {},
      timestamp: new Date().getTime(),
      value,
    };

    await this.collection.insertOne({
      ...transaction,
    });

    return transaction;
  }

  public async findAll(
    consumerId: string,
    timestamp1: number,
    timestamp2: number,
  ): Promise<Array<Transaction>> {
    return await this.collection
      .find(
        {
          consumerId,
          timestamp: { $gte: timestamp1, $lt: timestamp2 },
        },
        {
          sort: {
            timestamp: -1,
          },
        },
      )
      .toArray();
  }

  public async update(
    id: string,
    metadata: { [key: string]: string },
  ): Promise<void> {
    await this.collection.updateOne(
      {
        id,
      },
      {
        $set: {
          metadata,
        },
      },
    );
  }
}

import moment from 'moment';
import { Consumer, Transaction } from './models';
import { TransactionRepository } from './transaction.repository';

export class BeetleClient {
  constructor(protected transactionRepository: TransactionRepository) {}

  public async logs(consumerId: string): Promise<Array<Transaction>> {
    const timestamp1: number = moment()
      .subtract(1, 'months')
      .toDate()
      .getTime();

    const timestamp2: number = moment().endOf('months').toDate().getTime();

    return await this.transactionRepository.findAll(
      consumerId,
      timestamp1,
      timestamp2,
    );
  }

  public async transact(
    consumer: Consumer,
    value: number,
  ): Promise<{ id: string } | null> {
    let timestamp1: number = moment().startOf('months').toDate().getTime();

    let timestamp2: number = moment().endOf('months').toDate().getTime();

    if (consumer.subscription.frequency === 'daily') {
      timestamp1 = moment().startOf('days').toDate().getTime();

      timestamp2 = moment().endOf('days').toDate().getTime();
    }

    if (consumer.subscription.frequency === 'monthly') {
      timestamp1 = moment().startOf('months').toDate().getTime();

      timestamp2 = moment().endOf('months').toDate().getTime();
    }

    const transactions: Array<Transaction> =
      await this.transactionRepository.findAll(
        consumer.id,
        timestamp1,
        timestamp2,
      );

    const usage: number = transactions.reduce(
      (sum: number, x) => sum + x.value,
      0,
    );

    if (usage > consumer.subscription.limit) {
      return null;
    }

    const transaction: Transaction = await this.transactionRepository.create(
      consumer.id,
      value,
    );

    return {
      id: transaction.id,
    };
  }

  public async metadata(
    transactionId: string,
    metadata: { [key: string]: string },
  ): Promise<void> {
    await this.transactionRepository.update(transactionId, metadata);
  }
}

import { RouteOptions } from 'fastify';
import ip3country from 'ip3country';
import { Collection } from 'mongodb';
import { UAParser } from 'ua-parser-js';
import { PixelEvent, getContainer } from '../core';

ip3country.init();

export const PIXEL_EVENTS_POST: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<PixelEvent> =
      container.db.collection<PixelEvent>('pixel-events');

    const body: {
      consumerId: string;
      metadata: { [key: string]: string };
      tags: Array<string>;
      type: string;
    } = request.body as any;

    const country: string | null = request.headers['x-client-ip']
      ? ip3country.lookupStr(request.headers['x-client-ip'] as string)
      : null;

    const uaParser: UAParser = new UAParser(request.headers['user-agent']);

    const pixelEvent: PixelEvent = {
      consumerId: body.consumerId,
      country,
      ipAddress: (request.headers['x-client-ip'] as string | null) || '',
      metadata: body.metadata,
      referrer: request.headers['referer'] || null,
      tags: body.tags,
      timestamp: new Date().getTime(),
      type: body.type,
      userAgent: uaParser.getResult(),
    };

    await collection.insertOne({
      ...pixelEvent,
    });

    reply.status(200).send();
  },
  method: 'POST',
  url: '/api/v1/pixel/events',
  schema: {
    tags: ['pixel'],
    body: {
      type: 'object',
      properties: {
        consumerId: { type: 'string' },
        metadata: {
          type: 'object',
        },
        tags: {
          type: 'array',
          items: {
            type: 'string',
          },
        },
        type: { type: 'string' },
      },
    },
  },
};

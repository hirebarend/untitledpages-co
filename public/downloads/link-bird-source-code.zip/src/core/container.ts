import {
  ServiceBusClient,
  ServiceBusReceiver,
  ServiceBusSender,
} from '@azure/service-bus';
import { Db, MongoClient } from 'mongodb';
import { BeetleClient, TokenRepository, TransactionRepository } from './beetle';

export type Container = {
  beetleClient: BeetleClient;
  db: Db;
  serviceBusReceiver: ServiceBusReceiver;
  serviceBusSender: ServiceBusSender;
  tokenRepository: TokenRepository;
  transactionRepository: TransactionRepository;
};

let container: Container | null = null;

export async function getContainer() {
  if (container) {
    return container;
  }

  const mongoClient = await MongoClient.connect(
    process.env.MONGODB_CONNECTION_STRING as string,
  );

  const db = mongoClient.db('link-bird');

  if (!process.env.AZURE_SERVICE_BUS_CONNECTION_STRING) {
    throw Error();
  }

  const serviceBusClient: ServiceBusClient = new ServiceBusClient(
    process.env.AZURE_SERVICE_BUS_CONNECTION_STRING as string,
  );

  const tokenRepository: TokenRepository = new TokenRepository(db);

  const transactionRepository: TransactionRepository =
    new TransactionRepository(db);

  container = {
    beetleClient: new BeetleClient(transactionRepository),
    db,
    serviceBusReceiver: serviceBusClient.createReceiver('sbq-webhooks'),
    serviceBusSender: serviceBusClient.createSender('sbq-webhooks'),
    tokenRepository,
    transactionRepository,
  };

  return container;
}

import { RouteOptions } from 'fastify';
import { Collection } from 'mongodb';
import { Link, getContainer } from '../core';

export const LINKS_PUT: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<Link> = container.db.collection<Link>('links');

    const consumerId: string | null = process.env.DEBUG
      ? 'DEBUG_CONSUMER'
      : await container.tokenRepository.fromHeader(
          request.headers['authorization'],
        );

    if (!consumerId) {
      reply.status(401).send();

      return;
    }

    const params: { code: string } = request.params as any;

    const body: {
      cloak: boolean;
      code: string;
      expires: number | null;
      externalId: string | null;
      geoTargeting: Array<{ country: string; longUrl: string }>;
      longUrl: string;
      name: string | null;
      openGraph: {
        description: string;
        image: string;
        title: string;
      } | null;
      password: string | null;
      script: string | null;
      tags: Array<string>;
      webhook: string | null;
    } = request.body as any;

    await collection.updateOne(
      {
        code: params.code,
        consumerId,
      },
      {
        $set: {
          cloak: body.cloak,
          code: body.code,
          expires: body.expires,
          externalId: body.externalId,
          geoTargeting: body.geoTargeting,
          longUrl: body.longUrl,
          name: body.name,
          openGraph: body.openGraph,
          password: body.password,
          script: body.script,
          shortUrl: `https://lnkbrd.com/${body.code}`,
          tags: body.tags,
          updated: new Date().getTime(),
          webhook: body.webhook,
        },
      },
    );

    reply.status(200).send(body);
  },
  method: 'PUT',
  url: '/api/v1/links/:code',
  schema: {
    tags: ['links'],
    security: process.env.DEBUG
      ? undefined
      : [
          {
            apiKey: [],
          },
        ],
    body: {
      type: 'object',
      properties: {
        cloak: { type: 'boolean' },
        code: { type: 'string' },
        expires: { type: 'number', nullable: true },
        externalId: { type: 'string', nullable: true },
        geoTargeting: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              country: { type: 'string' },
              longUrl: { type: 'string' },
            },
          },
        },
        longUrl: { type: 'string' },
        name: { type: 'string', nullable: true },
        openGraph: {
          type: 'object',
          properties: {
            description: { type: 'string' },
            image: { type: 'string' },
            title: { type: 'string' },
          },
        },
        password: { type: 'string', nullable: true },
        script: { type: 'string', nullable: true },
        tags: {
          type: 'array',
          items: {
            type: 'string',
          },
        },
        webhook: { type: 'string', nullable: true },
      },
    },
  },
};

import axios from 'axios';
import { load } from 'cheerio';
import { faker } from '@faker-js/faker';
import { RouteOptions } from 'fastify';
import { Collection } from 'mongodb';
import { Link, getContainer } from '../core';

async function getOpenGraph(url: string) {
  try {
    const response = await axios.get(url);

    const $ = load(response.data);

    const title = $('title').html();

    const result: { [key: string]: string | null } = {};

    const keys = [
      'description',
      'og:description',
      'og:image',
      'og:site_name',
      'og:title',
      'og:type',
      'og:url',
      'title',
    ];

    for (const key of keys) {
      const element = $(`head meta[name=${key}]`);

      if (!element) {
        continue;
      }

      result[key] = element.attr('content') || null;
    }

    for (const key of keys) {
      const element = $(`head meta[property=${key}]`);

      if (!element) {
        continue;
      }

      result[key] = element.attr('content') || null;
    }

    return {
      description: result['og:description'],

      image: result['og:image'],

      title: result['og:title'] || title,
    };
  } catch {
    return null;
  }
}

export const LINKS_POST: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<Link> = container.db.collection<Link>('links');

    const consumerId: string | null = process.env.DEBUG
      ? 'DEBUG_CONSUMER'
      : await container.tokenRepository.fromHeader(
          request.headers['authorization'],
        );

    if (!consumerId) {
      reply.status(401).send();

      return;
    }

    const body: {
      code: string | null;
      expires: number | null;
      externalId: string | null;
      geoTargeting: Array<{ country: string; longUrl: string }> | null;
      longUrl: string;
      password: string | null;
      script: string | null;
      tags: Array<string> | null;
      webhook: string | null;
    } = request.body as any;

    const code: string =
      body.code ||
      faker.string.alphanumeric({
        casing: 'lower',
        length: 6,
      });

    if (await collection.findOne({ code })) {
      reply.status(409).send();

      return;
    }

    const link: Link = {
      clicks: {
        count: 0,
        timestamp: null,
      },
      cloak: false,
      code,
      consumerId,
      created: new Date().getTime(),
      expires: body.expires,
      externalId: body.externalId,
      geoTargeting: body.geoTargeting || [],
      longUrl: body.longUrl,
      name: null,
      openGraph: await getOpenGraph(body.longUrl),
      password: body.password,
      script: body.script,
      shortUrl: `https://lnkbrd.com/${code}`,
      tags: body.tags || [],
      updated: new Date().getTime(),
      webhook: body.webhook,
    };

    await collection.insertOne({
      ...link,
      consumerId,
    });

    reply.status(200).send(link);
  },
  method: 'POST',
  url: '/api/v1/links',
  schema: {
    tags: ['links'],
    security: process.env.DEBUG
      ? undefined
      : [
          {
            apiKey: [],
          },
        ],
    body: {
      type: 'object',
      properties: {
        code: { type: 'string', nullable: true },
        expires: { type: 'number', nullable: true },
        externalId: { type: 'string', nullable: true },
        geoTargeting: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              country: { type: 'string' },
              longUrl: { type: 'string' },
            },
          },
          nullable: true,
        },
        longUrl: { type: 'string' },
        password: { type: 'string', nullable: true },
        script: { type: 'string', nullable: true },
        tags: {
          type: 'array',
          items: {
            type: 'string',
          },
          nullable: true,
        },
        webhook: { type: 'string', nullable: true },
      },
    },
  },
};

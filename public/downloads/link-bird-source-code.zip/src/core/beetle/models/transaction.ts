export type Transaction = {
  consumerId: string;

  id: string;

  metadata: { [key: string]: string };

  timestamp: number;

  value: number;
};

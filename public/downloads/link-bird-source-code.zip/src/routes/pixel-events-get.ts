import { RouteOptions } from 'fastify';
import moment from 'moment';
import { Collection } from 'mongodb';
import { PixelEvent, getContainer } from '../core';

export const PIXEL_EVENTS_GET: RouteOptions = {
  handler: async (request, reply) => {
    const container = await getContainer();

    const collection: Collection<PixelEvent> =
      container.db.collection<PixelEvent>('pixel-events');

    const consumerId: string | null = process.env.DEBUG
      ? 'DEBUG_CONSUMER'
      : await container.tokenRepository.fromHeader(
          request.headers['authorization'],
        );

    if (!consumerId) {
      reply.status(401).send();

      return;
    }

    const pixelEvents: Array<PixelEvent> = await collection
      .find(
        {
          consumerId,
          timestamp: {
            $gte: moment().subtract(24, 'hours').toDate().getTime(),
          },
        },
        {
          projection: {
            _id: 0,
          },
          sort: {
            timestamp: -1,
          },
        },
      )
      .toArray();

    reply.status(200).send(pixelEvents);
  },
  method: 'GET',
  url: '/api/v1/pixel/events',
  schema: {
    tags: ['pixel'],
    security: process.env.DEBUG
      ? undefined
      : [
          {
            apiKey: [],
          },
        ],
  },
};
